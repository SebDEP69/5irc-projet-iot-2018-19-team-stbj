typedef struct {
    float latitude = 0;
    float longitude = 0;
    int fix = 0;
} coord;
